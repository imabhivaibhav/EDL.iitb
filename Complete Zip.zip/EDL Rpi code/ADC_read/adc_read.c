#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/adc.h"
#include "hardware/clocks.h"


// Define the GPIO pins for the LCD
const uint LCD_RS = 0;  // Replace 0 with the actual GPIO pin number
const uint LCD_E = 1;   // Replace 1 with the actual GPIO pin number
const uint LCD_D4 = 2;  // Replace 2 with the actual GPIO pin number
const uint LCD_D5 = 3;  // Replace 3 with the actual GPIO pin number
const uint LCD_D6 = 4;  // Replace 4 with the actual GPIO pin number
const uint LCD_D7 = 5;  // Replace 5 with the actual GPIO pin number

// Define the analog pin
const uint ANALOG_PIN = 26;  

// Define the clock pin
// const uint CLOCK_PIN = 27;  

// Callback function for the timer
// void timer_callback(uint alarm_num) {
//     // Toggle the GPIO pin to generate the clock signal
//     gpio_xor_mask(1u << CLOCK_PIN);
// }

// LCD commands
const uint8_t LCD_CLEAR_DISPLAY = 0x01;
const uint8_t LCD_RETURN_HOME = 0x02;
const uint8_t LCD_ENTRY_MODE_SET = 0x04;
const uint8_t LCD_DISPLAY_CONTROL = 0x08;
const uint8_t LCD_CURSOR_SHIFT = 0x10;
const uint8_t LCD_FUNCTION_SET = 0x20;
const uint8_t LCD_SET_CGRAM_ADDR = 0x40;
const uint8_t LCD_SET_DDRAM_ADDR = 0x80;

// Function prototypes
void initLCD();
void sendCommand(uint8_t cmd);
void sendData(uint8_t data);
void displayString(const char* str,uint8_t line);
void displayAnalogValue(uint16_t value,uint8_t line);
uint16_t readAnalogValue();

int main() {
    stdio_init_all();

    clock_gpio_init(21, CLOCKS_CLK_GPOUT0_CTRL_AUXSRC_VALUE_CLK_SYS, 12500000);//10Hz clock


    adc_init();
    adc_gpio_init(ANALOG_PIN);
    adc_select_input(0);

    float voltage;
    initLCD();
    while(true) {
        sendCommand(LCD_CLEAR_DISPLAY);  // Clear the LCD display

        uint16_t result = adc_read();

        // voltage=3.3/3348*(result-748);

        displayString("Final Output!",1);  // Display "Hello, World!" on the LCD
        displayAnalogValue(result,2);
        // char buffer[16];
        // snprintf(buffer, sizeof(buffer), "%d", i);  // Convert integer to string
        // displayString("Hello, World!",1);  // Display "Hello, World!" on the LCD
        // displayString(buffer,2);  // Display the integer on the second line

        printf("ADC Value: %d\n", result);  // Print voltage with 2 decimal places


        sleep_ms(50);
    }

    return 0;
}

void initLCD() {
    gpio_init(LCD_RS);
    gpio_init(LCD_E);
    gpio_init(LCD_D4);
    gpio_init(LCD_D5);
    gpio_init(LCD_D6);
    gpio_init(LCD_D7);
    
    gpio_set_dir(LCD_RS, GPIO_OUT);
    gpio_set_dir(LCD_E, GPIO_OUT);
    gpio_set_dir(LCD_D4, GPIO_OUT);
    gpio_set_dir(LCD_D5, GPIO_OUT);
    gpio_set_dir(LCD_D6, GPIO_OUT);
    gpio_set_dir(LCD_D7, GPIO_OUT);

    sleep_ms(15); // Wait for LCD to power up
    sendCommand(0x33);
    sendCommand(0x32); // 4-bit mode
    sendCommand(LCD_FUNCTION_SET | 0x08); // 2-line mode
    sendCommand(LCD_CLEAR_DISPLAY);
    sendCommand(LCD_ENTRY_MODE_SET | 0x06); // Increment cursor
    sendCommand(LCD_DISPLAY_CONTROL | 0x0C); // Display on, cursor off, blink off
}

void sendCommand(uint8_t cmd) {
    gpio_put(LCD_RS, 0);
    gpio_put(LCD_E, 0);

    gpio_put(LCD_D4, ((cmd >> 4) & 0x01));
    gpio_put(LCD_D5, ((cmd >> 5) & 0x01));
    gpio_put(LCD_D6, ((cmd >> 6) & 0x01));
    gpio_put(LCD_D7, ((cmd >> 7) & 0x01));
    
    gpio_put(LCD_E, 1);
    sleep_us(1);
    gpio_put(LCD_E, 0);

    gpio_put(LCD_D4, ((cmd >> 0) & 0x01));
    gpio_put(LCD_D5, ((cmd >> 1) & 0x01));
    gpio_put(LCD_D6, ((cmd >> 2) & 0x01));
    gpio_put(LCD_D7, ((cmd >> 3) & 0x01));
    
    gpio_put(LCD_E, 1);
    sleep_us(1);
    gpio_put(LCD_E, 0);

    sleep_ms(2); // Command execution time
}

void sendData(uint8_t data) {
    gpio_put(LCD_RS, 1);
    gpio_put(LCD_E, 0);

    gpio_put(LCD_D4, ((data >> 4) & 0x01));
    gpio_put(LCD_D5, ((data >> 5) & 0x01));
    gpio_put(LCD_D6, ((data >> 6) & 0x01));
    gpio_put(LCD_D7, ((data >> 7) & 0x01));
    
    gpio_put(LCD_E, 1);
    sleep_us(1);
    gpio_put(LCD_E, 0);

    gpio_put(LCD_D4, ((data >> 0) & 0x01));
    gpio_put(LCD_D5, ((data >> 1) & 0x01));
    gpio_put(LCD_D6, ((data >> 2) & 0x01));
    gpio_put(LCD_D7, ((data >> 3) & 0x01));
    
    gpio_put(LCD_E, 1);
    sleep_us(1);
    gpio_put(LCD_E, 0);

    sleep_us(50); // Data execution time
}

void displayString(const char* str, uint8_t line) {
    if (line == 1) {
        sendCommand(0x80);  // Set DDRAM address to start of first line
    } else if (line == 2) {
        sendCommand(0xC0);  // Set DDRAM address to start of second line
    }
    for (int i = 0; str[i] != '\0'; ++i) {
        sendData(str[i]);
    }
}

void displayAnalogValue(uint16_t value,uint8_t line) {
//    sendCommand(LCD_CLEAR_DISPLAY);
    char buffer[16];
    snprintf(buffer, sizeof(buffer), "ADC Val: %d", value);
    displayString(buffer,line);
}

uint16_t readAnalogValue() {
    adc_select_input(ANALOG_PIN);
    return adc_read();
}
